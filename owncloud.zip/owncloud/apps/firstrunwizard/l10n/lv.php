<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "Jūsu personīgie tīmekļa pakalpojumi. Visas jūsu datnes, kalendārs un citi dati vienuviet.",
"Get the apps to sync your files" => "Saņem lietotnes, lai sinhronizētu savas datnes",
"Connect your Calendar" => "Savienojiet savu kalendāru",
"Connect your Contacts" => "Savienojiet savus kontaktus",
"Access files via WebDAV" => "Piekļūstiet datnēm caur WebDAV",
"Documentation" => "Dokumentācija"
);
$PLURAL_FORMS = "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);";
