<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "Dine personlege nettenester. Alle filene, kontaktane og kalendrane dine med meir, på ein stad. ",
"Get the apps to sync your files" => "Få app-ar som kan synkronisera filene dine",
"Connect your Calendar" => "Kopla til kalenderen din",
"Connect your Contacts" => "Kopla til kontaktane dine",
"Access files via WebDAV" => "Bruk filene dine over WebDAV",
"Documentation" => "Dokumentasjon"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
