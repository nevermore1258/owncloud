OC.L10N.register(
    "files_external",
    {
    "External storage" : "ឃ្លាំងផ្ទុក​ខាងក្រៅ",
    "Personal" : "ផ្ទាល់​ខ្លួន",
    "Grant access" : "ទទួល​សិទ្ធិ​ចូល",
    "Saved" : "បាន​រក្សាទុក",
    "Username" : "ឈ្មោះ​អ្នកប្រើ",
    "Password" : "ពាក្យសម្ងាត់",
    "Save" : "រក្សាទុក",
    "Port" : "ច្រក",
    "WebDAV" : "WebDAV",
    "URL" : "URL",
    "Location" : "ទីតាំង",
    "Host" : "ម៉ាស៊ីន​ផ្ទុក",
    "Share" : "ចែក​រំលែក",
    "Name" : "ឈ្មោះ",
    "External Storage" : "ឃ្លាំងផ្ទុក​ខាងក្រៅ",
    "Folder name" : "ឈ្មោះ​ថត",
    "Configuration" : "ការ​កំណត់​សណ្ឋាន",
    "Add storage" : "បន្ថែម​ឃ្លាំងផ្ទុក",
    "Delete" : "លុប"
},
"nplurals=1; plural=0;");
