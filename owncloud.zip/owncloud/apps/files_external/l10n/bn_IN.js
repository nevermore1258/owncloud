OC.L10N.register(
    "files_external",
    {
    "Saved" : "সংরক্ষিত",
    "Save" : "সেভ",
    "URL" : "URL",
    "Host" : "হোস্ট",
    "Share" : "শেয়ার",
    "Name" : "নাম",
    "Folder name" : "ফোল্ডারের নাম",
    "Delete" : "মুছে ফেলা"
},
"nplurals=2; plural=(n != 1);");
