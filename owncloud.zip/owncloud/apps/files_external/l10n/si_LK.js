OC.L10N.register(
    "files_external",
    {
    "Personal" : "පෞද්ගලික",
    "Grant access" : "පිවිසුම ලබාදෙන්න",
    "Username" : "පරිශීලක නම",
    "Password" : "මුර පදය",
    "Save" : "සුරකින්න",
    "Port" : "තොට",
    "Region" : "කළාපය",
    "URL" : "URL",
    "Location" : "ස්ථානය",
    "ownCloud" : "ownCloud",
    "Host" : "සත්කාරකය",
    "Share" : "බෙදා හදා ගන්න",
    "Name" : "නම",
    "External Storage" : "භාහිර ගබඩාව",
    "Folder name" : "ෆොල්ඩරයේ නම",
    "Configuration" : "වින්‍යාසය",
    "Delete" : "මකා දමන්න"
},
"nplurals=2; plural=(n != 1);");
